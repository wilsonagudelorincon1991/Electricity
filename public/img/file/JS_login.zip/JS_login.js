$(function(){
  $("#btningresar").click(function(){
    if($("#textIdentificacion").val()!="" && $("#textPass").val()!=""){
      ValidarCredenciales();
    }else{
      alertify.alert("Ocurrio Un Error","Digite Sus Credenciales");
    }
  });
  function ValidarCredenciales(){
    $Datos={"user":$("#textIdentificacion").val(),"pass":$("#textPass").val()};
    $.ajax({
    type:"post",
        url:"../public/Login",
        data:$Datos,
        dataType:"json",
        success:function(Respuesta) {
            //alert(Respuesta+" --> "+Respuesta.estado);
          if(Respuesta.estado=="1") {
            //alert(Respuesta.tipo);
            if(Respuesta.tipo=="V"){
              window.location.href="FormMenuV.php";
            }else if(Respuesta.tipo=="TSS"){
              window.location.href="FormMenuTSS.php";
            }else if(Respuesta.tipo=="RH"){
              window.location.href="FormMenuRH.php";
            }else if(Respuesta.tipo=="JD"){
              window.location.href="FormMenuJD.php";
            }else if(Respuesta.tipo=="JM"){
              window.location.href="FormMenuJM.php";
            }else{
              window.location.href="login.php";
            }
          } else {
            alertify.alert("Notificacion de Error","Usuario O Contraseña Incorrecta");
          }
        }
      });
  }
});